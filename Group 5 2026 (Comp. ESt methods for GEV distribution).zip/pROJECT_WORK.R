library(ismev)    # gev.fit()  — MLE numerical optimization for GEV
library(lmomco)   # lmoms()    — computes sample L-moments from data
library(evd)      # rgev(), qgev(), fgev() — GEV random numbers and quantiles
library(ggplot2)  # Visualization
library(tidyr)    # pivot_longer() — reshape data for ggplot

library(RColorBrewer)
library(gridExtra)
library(scales)n
library(viridis)
library(patchwork)
library(dplyr)

# --- True GEV Parameters (the "population" we are estimating) ----------------
# GEV has 3 parameters:
#   mu    = location (shifts distribution left/right)
#   sigma = scale    (spreads or compresses; must be > 0)
#   xi    = shape    (tail behavior: >0 heavy tail, <0 bounded, =0 Gumbel)

true_mu    <- 0      # True location parameter
true_sigma <- 1      # True scale parameter
true_xi    <- -0.15 # True shape parameter (Frechet type, positive heavy tail)

# Collect true values in a named vector for easy lookup later
true_params <- c(mu = true_mu, sigma = true_sigma, xi = true_xi)

# --- Simulation Settings -----------------------------------------------------
n_sim        <- 1000              # Number of Monte Carlo replications per scenario
sample_sizes <- c(10, 20, 50,100, 300,500,1000)  # The four sample sizes to compare


# Method labels (used for naming results and plots)
methods <- c("MOM", "PWM", "LMOM", "LHMOM", "MLE", "LS", "WLS")

# Set seed so results are reproducible (same random numbers every run)
set.seed(123)




# -----------------------------------------------------------------------------
# 3a. METHOD OF MOMENTS (MOM)
# -----------------------------------------------------------------------------
# Theory:
#   Equate the first 3 theoretical moments of GEV to the sample moments:
#     1st moment: E[X]     = mu + sigma*(Gamma(1+xi) - 1)/xi
#     2nd moment: Var[X]   = sigma^2 * (Gamma(1+2xi) - Gamma(1+xi)^2) / xi^2
#     3rd moment: Skew[X]  = a known function of xi only
#
#   Step 1: Solve for xi by matching theoretical skewness to sample skewness
#           using uniroot() (numerical root-finding)
#   Step 2: Recover sigma from variance formula
#   Step 3: Recover mu from mean formula

mom_gev <- function(x) {
  
  # --- Sample moments ---
  m1 <- mean(x)       # Sample mean (1st moment)
  m2 <- var(x)        # Sample variance (unbiased, divides by n-1)
  n  <- length(x)
  
  # Sample skewness: standardized 3rd central moment
  # Using bias-corrected formula: [n / ((n-1)(n-2))] * sum((xi - xbar)/sd)^3
  m3 <- (n / ((n - 1) * (n - 2))) * sum(((x - m1) / sqrt(m2))^3)
  
  # --- Theoretical GEV skewness as a function of xi ---
  # Returns (theoretical_skewness - sample_skewness) so that uniroot finds xi
  # where the difference = 0 (i.e., theoretical matches sample)
  gev_skew <- function(xi) {
    if (abs(xi) < 1e-6) {
      # Special case: xi -> 0 gives Gumbel, skewness = 1.13955 (fixed constant)
      return(1.13955 - m3)
    }
    if (xi <= -1/3) return(NA)    # 3rd moment only exists when xi > -1/3
    
    # Gamma functions appear in GEV moment formulas
    g1 <- gamma(1 + xi)           # Gamma(1 + xi)
    g2 <- gamma(1 + 2 * xi)       # Gamma(1 + 2*xi)
    g3 <- gamma(1 + 3 * xi)       # Gamma(1 + 3*xi)
    
    num   <- g3 - 3 * g1 * g2 + 2 * g1^3   # Numerator of skewness
    denom <- (g2 - g1^2)^(3/2)              # Denominator (std dev)^3
    
    if (denom <= 0) return(NA)
    return(num / denom - m3)      # = 0 when theoretical skew = sample skew
  }
  
  # --- Step 1: Solve for xi using uniroot (bisection-style root finder) ---
  # Search in interval (-0.3, 0.49): outside this range moments may not exist
  xi_hat <- tryCatch(
    uniroot(gev_skew, interval = c(-0.3, 0.49))$root,
    error = function(e) NA
  )
  if (is.na(xi_hat)) return(c(mu = NA, sigma = NA, xi = NA))
  
  # --- Step 2: Recover sigma from variance formula ---
  # Var[X] = sigma^2 * (Gamma(1+2xi) - Gamma(1+xi)^2) / xi^2
  # Rearranged: sigma = sqrt(Var[X] * xi^2 / (Gamma(1+2xi) - Gamma(1+xi)^2))
  g1 <- gamma(1 + xi_hat)
  g2 <- gamma(1 + 2 * xi_hat)
  
  sigma_hat <- tryCatch(
    sqrt(m2 * xi_hat^2 / (g2 - g1^2)),
    error = function(e) NA
  )
  if (is.na(sigma_hat) || sigma_hat <= 0) return(c(mu = NA, sigma = NA, xi = NA))
  
  # --- Step 3: Recover mu from mean formula ---
  # E[X] = mu + sigma*(Gamma(1+xi) - 1)/xi
  # Rearranged: mu = E[X] - sigma*(Gamma(1+xi) - 1)/xi
  mu_hat <- m1 - sigma_hat * (g1 - 1) / xi_hat
  
  return(c(mu = mu_hat, sigma = sigma_hat, xi = xi_hat))
}


# -----------------------------------------------------------------------------
# 3b. PROBABILITY WEIGHTED MOMENTS (PWM)
# -----------------------------------------------------------------------------
# Theory (Hosking et al., 1985):
#   PWM: beta_r = E[X * F(X)^r]  where F = CDF
#   Sample estimators:
#     beta_0 = mean(x)
#     beta_1 = (1/n) * sum x_(i) * (i-1)/(n-1)
#     beta_2 = (1/n) * sum x_(i) * (i-1)(i-2)/[(n-1)(n-2)]
#
#   GEV parameters recovered from beta_0, beta_1, beta_2 via
#   rational polynomial approximation (Hosking 1985)
#
# Note: PWM and L-moments are mathematically equivalent — same information,
#       different representation. L-moments are linear combinations of PWMs.

pwm_gev <- function(x) {
  
  n        <- length(x)
  x_sorted <- sort(x)       # Must sort ascending for order statistics
  i_seq    <- 1:n           # Rank indices i = 1, 2, ..., n
  
  # --- Compute the three PWM estimators ---
  
  # beta_0 = E[X] = sample mean (no weighting by F)
  beta0 <- mean(x_sorted)
  
  # beta_1 = E[X * F(X)] — weight each x_(i) by its rank fraction
  # Unbiased estimator uses (i-1)/(n-1) as weight
  w1    <- (i_seq - 1) / (n - 1)           # Weights proportional to rank
  beta1 <- sum(x_sorted * w1) / n          # (1/n) * sum of weighted order stats
  
  # beta_2 = E[X * F(X)^2] — weight by squared rank fraction
  w2    <- ((i_seq - 1) * (i_seq - 2)) / ((n - 1) * (n - 2))
  beta2 <- sum(x_sorted * w2) / n
  
  # --- Recover xi from PWMs using Hosking's approximation ---
  # c_val is an intermediate variable that maps beta's to shape
  # Formula: c = (2*beta1 - beta0) / (3*beta2 - beta0) - log(2)/log(3)
  c_val  <- (2 * beta1 - beta0) / (3 * beta2 - beta0) - log(2) / log(3)
  
  # Rational approximation for xi (Hosking & Wallis 1997):
  xi_hat <- 7.8590 * c_val + 2.9554 * c_val^2
  
  # --- Recover sigma from PWMs ---
  # sigma = xi*(2*beta1 - beta0) / [Gamma(1+xi) * (1 - 2^(-xi))]
  sigma_hat <- tryCatch({
    xi_hat * (2 * beta1 - beta0) / (gamma(1 + xi_hat) * (1 - 2^(-xi_hat)))
  }, error = function(e) NA)
  
  if (is.na(sigma_hat) || sigma_hat <= 0) return(c(mu = NA, sigma = NA, xi = NA))
  
  # --- Recover mu from PWMs ---
  # mu = beta0 - sigma*(Gamma(1+xi) - 1)/xi
  mu_hat <- beta0 - sigma_hat * (gamma(1 + xi_hat) - 1) / xi_hat
  
  return(c(mu = mu_hat, sigma = sigma_hat, xi = xi_hat))
}


# -----------------------------------------------------------------------------
# 3c. L-MOMENTS (LMOM)
# -----------------------------------------------------------------------------
# Theory (Hosking, 1990):
#   L-moments are linear combinations of order statistics:
#     lambda_1 = E[X]                          (L-mean)
#     lambda_2 = E[X_(2:2) - X_(1:2)] / 2     (L-scale, always > 0)
#     tau_3    = lambda_3 / lambda_2            (L-skewness)
#
#   Advantages over classical moments:
#     - Always exist (no finite higher moment requirement)
#     - More robust to outliers (linear, not squared/cubed)
#     - Preferred in hydrology for flood frequency analysis
#
#   lmomco::lmoms() computes all sample L-moments efficiently

lmom_gev <- function(x) {
  
  # lmoms() computes sample L-moments: lambdas and ratios (tau)
  # nmom=4: compute first 4 L-moments
  lmom <- lmoms(x, nmom = 4)
  
  if (any(is.na(lmom$lambdas))) return(c(mu = NA, sigma = NA, xi = NA))
  
  # tau_3 = L-skewness ratio = lambda_3 / lambda_2
  tau3    <- lmom$ratios[3]   # ratios[3] = tau_3 (L-skewness)
  lambda2 <- lmom$lambdas[2]  # lambda_2 = L-scale
  lambda1 <- lmom$lambdas[1]  # lambda_1 = L-mean
  
  # --- Estimate xi from tau_3 (Hosking 1990 rational approximation) ---
  z      <- 2 / (3 + tau3) - log(2) / log(3)   # Intermediate variable
  xi_hat <- 7.859 * z + 2.9554 * z^2           # Polynomial approximation
  
  # --- Recover sigma from L-scale ---
  # lambda_2 = sigma * Gamma(1+xi) * (1 - 2^(-xi)) / xi
  # Rearranged: sigma = lambda_2 * xi / [Gamma(1+xi) * (1 - 2^(-xi))]
  sigma_hat <- tryCatch({
    lambda2 * xi_hat / (gamma(1 + xi_hat) * (1 - 2^(-xi_hat)))
  }, error = function(e) NA)
  
  if (is.na(sigma_hat) || sigma_hat <= 0) return(c(mu = NA, sigma = NA, xi = NA))
  
  # --- Recover mu from L-mean ---
  mu_hat <- lambda1 - sigma_hat * (gamma(1 + xi_hat) - 1) / xi_hat
  
  return(c(mu = mu_hat, sigma = sigma_hat, xi = xi_hat))
}


# -----------------------------------------------------------------------------
# 3d. LH-MOMENTS (LHMOM) — Wang (1997)
# -----------------------------------------------------------------------------
# Theory:
#   LH-moments are higher-order L-moments that place more weight on the
#   UPPER part of the distribution (large observations).
#   This is particularly useful for extreme value analysis where the
#   upper tail is most important.
#
#   Parameter eta controls the "level":
#     eta = 0 -> standard L-moments (same as LMOM)
#     eta = 1 -> first-level LH-moments (emphasize top 50% of data)
#     eta = 2 -> second-level LH-moments (emphasize top 33% of data)
#
#   Implementation strategy:
#     Shift the analysis to observations ranked (eta+1) to n
#     Then apply L-moment estimation on this upper portion
#     This approximates the theoretical LH-moment weighting

lh_mom_gev <- function(x, eta = 1) {
  # eta: LH-moment level (integer >= 0)
  
  n        <- length(x)
  x_sorted <- sort(x)   # Sort ascending so x_sorted[n] is the maximum
  
  # Need enough data above the eta-th order statistic
  if (n <= eta + 2) return(c(mu = NA, sigma = NA, xi = NA))
  
  # Use upper (n - eta) observations: from rank eta+1 to rank n
  # These are the observations that receive non-zero weight in LH-moments
  x_upper <- x_sorted[(eta + 1):n]
  
  # Apply L-moment estimation on the upper portion
  # This is the key difference from LMOM: we're focusing on upper tail data
  lmom_upper <- tryCatch(
    lmoms(x_upper, nmom = 3),
    error = function(e) NULL
  )
  
  if (is.null(lmom_upper) || any(is.na(lmom_upper$lambdas))) {
    return(c(mu = NA, sigma = NA, xi = NA))
  }
  
  # Same rational approximation as L-moments
  tau3    <- lmom_upper$ratios[3]
  lambda2 <- lmom_upper$lambdas[2]
  lambda1 <- lmom_upper$lambdas[1]
  
  z      <- 2 / (3 + tau3) - log(2) / log(3)
  xi_hat <- 7.859 * z + 2.9554 * z^2
  
  sigma_hat <- tryCatch({
    lambda2 * xi_hat / (gamma(1 + xi_hat) * (1 - 2^(-xi_hat)))
  }, error = function(e) NA)
  
  if (is.na(sigma_hat) || sigma_hat <= 0) return(c(mu = NA, sigma = NA, xi = NA))
  
  mu_hat <- lambda1 - sigma_hat * (gamma(1 + xi_hat) - 1) / xi_hat
  
  return(c(mu = mu_hat, sigma = sigma_hat, xi = xi_hat))
}


# -----------------------------------------------------------------------------
# 3e. MAXIMUM LIKELIHOOD ESTIMATION (MLE)
# -----------------------------------------------------------------------------
# Theory:
#   MLE finds parameters that maximize the GEV log-likelihood:
#     log L(mu,sigma,xi|x) =
#       -n*log(sigma)
#       -(1 + 1/xi) * sum(log(1 + xi*(x_i - mu)/sigma))
#       - sum((1 + xi*(x_i - mu)/sigma)^(-1/xi))
#
#   No closed form — solved numerically by gev.fit() using BFGS optimization.
#
#   Properties:
#     + Asymptotically efficient (achieves Cramer-Rao lower bound for large n)
#     + Uses ALL information in the likelihood
#     - Can fail to converge for small n (especially n=10)
#     - Sensitive to outliers more than L-moments
#
#   We use ismev::gev.fit() as primary, evd::fgev() as fallback

mle_gev <- function(x) {
  
  # Primary: ismev::gev.fit() — returns mle = c(mu, sigma, xi)
  fit <- tryCatch(
    gev.fit(x, show = FALSE),    # show=FALSE: suppress convergence output
    error = function(e) NULL
  )
  
  # Check convergence: conv=0 means successful
  if (!is.null(fit) && fit$conv == 0) {
    return(c(mu = fit$mle[1], sigma = fit$mle[2], xi = fit$mle[3]))
  }
  
  # Fallback: evd::fgev() uses a different optimizer
  # Useful when ismev fails (common at n=10 with extreme samples)
  fit2 <- tryCatch(
    fgev(x),
    error = function(e) NULL
  )
  
  if (is.null(fit2)) return(c(mu = NA, sigma = NA, xi = NA))
  
  params <- fit2$estimate   # Named vector: loc, scale, shape
  return(c(mu = params["loc"], sigma = params["scale"], xi = params["shape"]))
}


# -----------------------------------------------------------------------------
# 3f. ORDINARY LEAST SQUARES (LS)
# -----------------------------------------------------------------------------
# Theory:
#   1. Assign empirical probabilities using Gringorten plotting positions:
#        p_i = (i - 0.44) / (n + 0.12)   for i = 1, 2, ..., n
#      (Gringorten 1963 — optimal plotting position for GEV/Gumbel)
#
#   2. The theoretical GEV quantile function (inverse CDF) gives:
#        Q(p) = mu + (sigma/xi) * [(-log p)^(-xi) - 1]   for xi != 0
#        Q(p) = mu - sigma * log(-log p)                  for xi = 0 (Gumbel)
#
#   3. Minimize: sum_{i=1}^{n} [x_(i) - Q(p_i)]^2
#      over parameters (mu, sigma, xi) using Nelder-Mead optimization
#
#   Note: sigma is optimized as log(sigma) internally to ensure sigma > 0
#         during unconstrained optimization

ls_gev <- function(x) {
  
  n        <- length(x)
  x_sorted <- sort(x)
  i_seq    <- 1:n
  
  # Gringorten plotting positions: optimal for GEV family
  p_i <- (i_seq - 0.44) / (n + 0.12)
  p_i <- pmax(pmin(p_i, 0.9999), 0.0001)   # Clip to avoid log(0)
  
  # Objective: sum of squared residuals (to minimize)
  obj_ls <- function(params) {
    mu    <- params[1]
    sigma <- params[2]    # sigma already > 0 (constrained by lower bound in optim)
    xi    <- params[3]
    
    if (sigma <= 0) return(1e10)  # Hard penalty for invalid sigma
    
    # Theoretical GEV quantiles at plotting positions (from evd package)
    q_theo <- tryCatch(
      qgev(p_i, loc = mu, scale = sigma, shape = xi),
      error = function(e) rep(NA, n)
    )
    
    if (any(is.na(q_theo) | is.infinite(q_theo))) return(1e10)
    
    sum((x_sorted - q_theo)^2)   # Ordinary sum of squared residuals
  }
  
  # Use L-moments as starting values: better starting point = faster convergence
  start_params <- tryCatch(
    lmom_gev(x),
    error = function(e) c(mean(x), sd(x) * 0.78, 0.1)
  )
  if (any(is.na(start_params))) start_params <- c(mean(x), sd(x) * 0.78, 0.1)
  
  # Nelder-Mead: derivative-free simplex method, robust for non-smooth objectives
  fit <- tryCatch(
    optim(start_params, obj_ls, method = "Nelder-Mead",
          control = list(maxit = 5000, reltol = 1e-8)),
    error = function(e) NULL
  )
  
  if (is.null(fit) || fit$convergence != 0) return(c(mu = NA, sigma = NA, xi = NA))
  
  params <- fit$par
  if (params[2] <= 0) return(c(mu = NA, sigma = NA, xi = NA))
  
  return(c(mu = params[1], sigma = params[2], xi = params[3]))
}


# -----------------------------------------------------------------------------
# 3g. WEIGHTED LEAST SQUARES (WLS)
# -----------------------------------------------------------------------------
# Theory:
#   Identical to LS, but each squared residual gets a weight w_i:
#     minimize: sum_{i=1}^{n} w_i * [x_(i) - Q(p_i)]^2
#
#   Weight choice:
#     The i-th order statistic from Uniform(0,1) has variance:
#       Var(U_(i:n)) = i*(n-i+1) / [(n+1)^2 * (n+2)]
#     We use w_i = 1 / Var(U_(i:n))
#
#   Interpretation:
#     - Central order statistics have SMALLER variance -> higher weight
#     - Extreme order statistics (i=1 or i=n) have LARGER variance -> lower weight
#     - This is the OPPOSITE of LH-moments (which upweight extremes)
#     - WLS is more conservative / stable than LS

wls_gev <- function(x) {
  
  n        <- length(x)
  x_sorted <- sort(x)
  i_seq    <- 1:n
  
  # Gringorten plotting positions (same as LS)
  p_i <- (i_seq - 0.44) / (n + 0.12)
  p_i <- pmax(pmin(p_i, 0.9999), 0.0001)
  
  # --- Compute weights from order statistic variance ---
  # Var(U_(i:n)) = i*(n-i+1) / [(n+1)^2 * (n+2)]
  var_p   <- (i_seq * (n - i_seq + 1)) / ((n + 1)^2 * (n + 2))
  weights <- 1 / var_p          # Inverse variance weights
  weights <- weights / sum(weights)   # Normalize to sum = 1
  
  # Weighted objective function
  obj_wls <- function(params) {
    mu    <- params[1]
    sigma <- params[2]
    xi    <- params[3]
    
    if (sigma <= 0) return(1e10)
    
    q_theo <- tryCatch(
      qgev(p_i, loc = mu, scale = sigma, shape = xi),
      error = function(e) rep(NA, n)
    )
    
    if (any(is.na(q_theo) | is.infinite(q_theo))) return(1e10)
    
    sum(weights * (x_sorted - q_theo)^2)   # WEIGHTED sum of squared residuals
  }
  
  # Start from L-moment estimates (same strategy as LS)
  start_params <- tryCatch(
    lmom_gev(x),
    error = function(e) c(mean(x), sd(x) * 0.78, 0.1)
  )
  if (any(is.na(start_params))) start_params <- c(mean(x), sd(x) * 0.78, 0.1)
  
  fit <- tryCatch(
    optim(start_params, obj_wls, method = "Nelder-Mead",
          control = list(maxit = 5000, reltol = 1e-8)),
    error = function(e) NULL
  )
  
  if (is.null(fit) || fit$convergence != 0) return(c(mu = NA, sigma = NA, xi = NA))
  
  params <- fit$par
  if (params[2] <= 0) return(c(mu = NA, sigma = NA, xi = NA))
  
  return(c(mu = params[1], sigma = params[2], xi = params[3]))
}


# =============================================================================
# SECTION 4: RMSE COMPUTATION FUNCTION
# =============================================================================
# RMSE = Root Mean Square Error
# Formula: RMSE = sqrt( (1/K) * sum_{k=1}^{K} (theta_hat_k - theta_true)^2 )
#   where K = number of successful (non-NA) replications
#
# Interpretation:
#   - RMSE combines both BIAS and VARIANCE into one number:
#       RMSE^2 = Bias^2 + Variance
#   - Lower RMSE = better estimator overall
#   - An unbiased estimator can still have high RMSE if variance is large

compute_rmse <- function(estimates, true_value) {
  # estimates : vector of length n_sim (some may be NA due to failed runs)
  # true_value: scalar, the known true parameter value
  
  estimates_clean <- estimates[!is.na(estimates)]   # Remove NAs
  
  if (length(estimates_clean) == 0) return(NA)      # All runs failed
  
  sqrt(mean((estimates_clean - true_value)^2))      # RMSE formula
}


# =============================================================================
# SECTION 5: MAIN SIMULATION LOOP
# =============================================================================
# Structure:
#   Outer loop: over sample sizes n = 10, 20, 50, 150
#   Inner loop: over n_sim = 1000 replications
#     Each replication:
#       1. Generate ONE GEV sample of size n
#       2. Apply ALL 7 estimators to the SAME sample
#       3. Store estimates
#
# Why loops and not vectorization?
#   - Each replication requires a fresh random sample x
#   - That SAME x is passed to all 7 estimators for fair comparison
#   - Inner solvers (optim, uniroot) are inherently scalar — cannot be batched
#   - Loop is easy to read, debug, and extend

cat("==========================================================\n")
cat("     GEV PARAMETER ESTIMATION SIMULATION STUDY\n")
cat("==========================================================\n")
cat(sprintf("True: mu=%.1f | sigma=%.1f | xi=%.1f\n", true_mu, true_sigma, true_xi))
cat(sprintf("Replications: %d | Sample sizes: %s\n\n",
            n_sim, paste(sample_sizes, collapse = ", ")))


# --- Pre-allocate storage ---
# Structure: results[[method]][[n_as_string]][[parameter]] = numeric vector of length n_sim
# Pre-allocation avoids slow memory re-allocation inside the loop

results <- list()
for (meth in methods) {
  results[[meth]] <- list()
  for (n_str in as.character(sample_sizes)) {
    results[[meth]][[n_str]] <- list(
      mu    = numeric(n_sim),   # Will store n_sim estimates of mu
      sigma = numeric(n_sim),   # Will store n_sim estimates of sigma
      xi    = numeric(n_sim)    # Will store n_sim estimates of xi
    )
  }
}

# --- Run simulation ---

for (n in sample_sizes) {
  n_str <- as.character(n)
  cat(sprintf("Running n = %d ...\n", n))
  
  for (sim in 1:n_sim) {
    
    # Generate one GEV random sample of size n
    # rgev() from evd: loc=mu, scale=sigma, shape=xi
    x <- rgev(n, loc = true_mu, scale = true_sigma, shape = true_xi)
    
    # Apply each estimator and store results
    # tryCatch ensures that if an estimator crashes, we store NA and continue
    
    est <- tryCatch(mom_gev(x),        error = function(e) c(NA, NA, NA))
    results[["MOM"]][[n_str]]$mu[sim]    <- est[1]
    results[["MOM"]][[n_str]]$sigma[sim] <- est[2]
    results[["MOM"]][[n_str]]$xi[sim]    <- est[3]
    
    est <- tryCatch(pwm_gev(x),        error = function(e) c(NA, NA, NA))
    results[["PWM"]][[n_str]]$mu[sim]    <- est[1]
    results[["PWM"]][[n_str]]$sigma[sim] <- est[2]
    results[["PWM"]][[n_str]]$xi[sim]    <- est[3]
    
    est <- tryCatch(lmom_gev(x),       error = function(e) c(NA, NA, NA))
    results[["LMOM"]][[n_str]]$mu[sim]    <- est[1]
    results[["LMOM"]][[n_str]]$sigma[sim] <- est[2]
    results[["LMOM"]][[n_str]]$xi[sim]    <- est[3]
    
    est <- tryCatch(lh_mom_gev(x, eta=1), error = function(e) c(NA, NA, NA))
    results[["LHMOM"]][[n_str]]$mu[sim]    <- est[1]
    results[["LHMOM"]][[n_str]]$sigma[sim] <- est[2]
    results[["LHMOM"]][[n_str]]$xi[sim]    <- est[3]
    
    est <- tryCatch(mle_gev(x),        error = function(e) c(NA, NA, NA))
    results[["MLE"]][[n_str]]$mu[sim]    <- est[1]
    results[["MLE"]][[n_str]]$sigma[sim] <- est[2]
    results[["MLE"]][[n_str]]$xi[sim]    <- est[3]
    
    est <- tryCatch(ls_gev(x),         error = function(e) c(NA, NA, NA))
    results[["LS"]][[n_str]]$mu[sim]    <- est[1]
    results[["LS"]][[n_str]]$sigma[sim] <- est[2]
    results[["LS"]][[n_str]]$xi[sim]    <- est[3]
    
    est <- tryCatch(wls_gev(x),        error = function(e) c(NA, NA, NA))
    results[["WLS"]][[n_str]]$mu[sim]    <- est[1]
    results[["WLS"]][[n_str]]$sigma[sim] <- est[2]
    results[["WLS"]][[n_str]]$xi[sim]    <- est[3]
    
  } # end inner loop (replications)
  
  cat(sprintf("  Done: n = %d complete.\n", n))
} # end outer loop (sample sizes)

cat("\nAll simulations complete.\n\n")


# =============================================================================
# SECTION 6: COMPUTE RMSE TABLE
# =============================================================================
# For every combination of: method x sample size x parameter
# Compute the RMSE using the compute_rmse() function defined above

rmse_rows <- list()   # Will collect one data.frame row per method x sample size

for (meth in methods) {
  for (n in sample_sizes) {
    n_str <- as.character(n)
    
    # Compute RMSE for each of the 3 parameters
    rmse_mu    <- compute_rmse(results[[meth]][[n_str]]$mu,    true_params["mu"])
    rmse_sigma <- compute_rmse(results[[meth]][[n_str]]$sigma, true_params["sigma"])
    rmse_xi    <- compute_rmse(results[[meth]][[n_str]]$xi,    true_params["xi"])
    
    rmse_rows[[length(rmse_rows) + 1]] <- data.frame(
      Method     = meth,
      n          = n,
      RMSE_mu    = round(rmse_mu,    5),
      RMSE_sigma = round(rmse_sigma, 5),
      RMSE_xi    = round(rmse_xi,    5),
      # Total RMSE: average across all 3 parameters for overall ranking
      RMSE_Total = round(mean(c(rmse_mu, rmse_sigma, rmse_xi), na.rm = TRUE), 5)
    )
  }
}

# Combine all rows into one data frame
rmse_table <- do.call(rbind, rmse_rows)
rownames(rmse_table) <- NULL


# =============================================================================
# SECTION 7: COMPUTE MEAN ESTIMATES TABLE (Bias analysis)
# =============================================================================
# Mean estimate across 1000 replications tells us about BIAS:
#   Bias = E[theta_hat] - theta_true
#   Unbiased: Bias = 0 (estimates centered on true value)
#   Biased:   Bias != 0 (estimates systematically too high or too low)

est_rows <- list()

for (meth in methods) {
  for (n in sample_sizes) {
    n_str <- as.character(n)
    
    for (param in c("mu", "sigma", "xi")) {
      ests       <- results[[meth]][[n_str]][[param]]
      ests_clean <- ests[!is.na(ests)]
      true_val   <- true_params[param]
      
      est_rows[[length(est_rows) + 1]] <- data.frame(
        Method     = meth,
        n          = n,
        Parameter  = param,
        True_Value = true_val,
        Mean_Est   = round(mean(ests_clean),   4),
        Median_Est = round(median(ests_clean), 4),
        Bias       = round(mean(ests_clean) - true_val, 4),
        Std_Dev    = round(sd(ests_clean),    4),
        N_Valid    = length(ests_clean),
        N_Failed   = n_sim - length(ests_clean)
      )
    }
  }
}

estimates_table <- do.call(rbind, est_rows)
rownames(estimates_table) <- NULL

estimates_table
# =============================================================================
# SECTION 8: PRINT RESULTS TO CONSOLE
# =============================================================================

# --- 8a. RMSE Table per sample size ---
cat("==========================================================\n")
cat("              RMSE COMPARISON TABLE\n")
cat("==========================================================\n")
cat(sprintf("True: mu=%.1f | sigma=%.1f | xi=%.1f\n\n", true_mu, true_sigma, true_xi))

for (n in sample_sizes) {
  cat(sprintf("--- n = %d ---\n", n))
  sub <- rmse_table[rmse_table$n == n,
                    c("Method","RMSE_mu","RMSE_sigma","RMSE_xi","RMSE_Total")]
  print(sub, row.names = FALSE)
  cat("\n")
}

# --- 8b. Best method per sample size ---
cat("==========================================================\n")
cat("   BEST METHOD (LOWEST RMSE) PER SAMPLE SIZE\n")
cat("==========================================================\n")

for (n in sample_sizes) {
  sub        <- rmse_table[rmse_table$n == n, ]
  best_mu    <- sub$Method[which.min(sub$RMSE_mu)]
  best_sigma <- sub$Method[which.min(sub$RMSE_sigma)]
  best_xi    <- sub$Method[which.min(sub$RMSE_xi)]
  best_total <- sub$Method[which.min(sub$RMSE_Total)]
  
  cat(sprintf(
    "n=%3d | mu: %-6s | sigma: %-6s | xi: %-6s | Overall: %-6s\n",
    n, best_mu, best_sigma, best_xi, best_total))
}

# --- 8c. Mean estimates wide table (Bias at a glance) ---
cat("\n==========================================================\n")
cat("  MEAN ESTIMATES vs TRUE VALUE (Bias at a glance)\n")
cat("==========================================================\n")

for (n in sample_sizes) {
  cat(sprintf("\n--- n = %d ---\n", n))
  cat(sprintf("%-6s  %8s %+8s  %8s %+8s  %8s %+8s\n",
              "Method", "E[mu]","Bias", "E[sig]","Bias", "E[xi]","Bias"))
  cat(paste(rep("-", 65), collapse=""), "\n")
  
  for (meth in methods) {
    sub <- estimates_table[estimates_table$n == n & estimates_table$Method == meth, ]
    r_mu  <- sub[sub$Parameter == "mu",    ]
    r_sig <- sub[sub$Parameter == "sigma", ]
    r_xi  <- sub[sub$Parameter == "xi",   ]
    
    cat(sprintf("%-6s  %8.4f %+8.4f  %8.4f %+8.4f  %8.4f %+8.4f\n",
                meth,
                r_mu$Mean_Est,  r_mu$Bias,
                r_sig$Mean_Est, r_sig$Bias,
                r_xi$Mean_Est,  r_xi$Bias))
  }
}

# --- 8d. Bias-Variance decomposition at n=50 ---
cat("\n==========================================================\n")
cat("  BIAS-VARIANCE DECOMPOSITION at n = 50\n")
cat("  RMSE^2 = Bias^2 + Variance\n")
cat("==========================================================\n\n")

n_focus <- "50"
for (meth in methods) {
  cat(sprintf("Method: %s\n", meth))
  for (param in c("mu", "sigma", "xi")) {
    ests  <- results[[meth]][[n_focus]][[param]]
    ests  <- ests[!is.na(ests)]
    tv    <- true_params[param]
    bias  <- mean(ests) - tv
    vari  <- var(ests)
    rmse  <- sqrt(bias^2 + vari)
    cat(sprintf("  %5s | Bias=%+.4f | Var=%.4f | RMSE=%.4f\n",
                param, bias, vari, rmse))
  }
  cat("\n")
}


# =============================================================================
# SECTION 9: PUBLICATION-QUALITY VISUALIZATIONS FOR SHAPE PARAMETER (ξ)
# =============================================================================

# Load required packages
library(ggplot2)
library(reshape2)


# --- Set color palette for methods ---
method_colors <- RColorBrewer::brewer.pal(min(8, length(methods)), "Set1")
names(method_colors) <- methods

# --- Plot 1: RMSE vs Sample Size for ξ ---------------------------------------
# Shows how RMSE of ξ estimates decreases with sample size

p1_rmse <- ggplot(rmse_table, aes(x = n, y = RMSE_xi, color = Method, group = Method)) +
  geom_line(size = 1.5) +
  geom_point(size = 3.5, shape = 21, fill = "white", stroke = 1.2) +
  scale_x_log10(breaks = sample_sizes,
                labels = sample_sizes) +
  scale_y_continuous(breaks = pretty_breaks()) +
  scale_color_manual(values = method_colors) +
  labs(x = expression("Sample Size" ~ italic(n)),
       y = "Root Mean Square Error (RMSE)",
       title = expression("RMSE of" ~ hat(xi) ~ "Estimates"),
       subtitle = sprintf("True ξ = %.2f | Lower RMSE indicates better estimation", true_xi),
       color = "Method") +
  theme_bw(base_size = 13) +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
        plot.subtitle = element_text(hjust = 0.5, size = 12, color = "gray40"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text = element_text(size = 11),
        legend.position = "bottom",
        legend.title = element_text(face = "bold"),
        legend.text = element_text(size = 10),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(color = "gray90", size = 0.5)) +
  guides(color = guide_legend(nrow = 2, byrow = TRUE))

print(p1_rmse)

# --- Plot 2: Boxplot of ξ Estimates at n=50 -----------------------------------
# Shows distribution, bias, and spread of estimates

# Prepare data with winsorization for extreme outliers
xi_data <- data.frame()
for (m in methods) {
  v <- results[[m]][["50"]]$xi
  v <- v[!is.na(v) & is.finite(v)]
  # Winsorize at 1st and 99th percentiles
  if (length(v) > 0) {
    q <- quantile(v, c(0.01, 0.99), na.rm = TRUE)
    v <- pmax(pmin(v, q[2]), q[1])
    xi_data <- rbind(xi_data, 
                     data.frame(Method = m, xi = v))
  }
}

# Calculate summary statistics
xi_summary <- xi_data %>%
  group_by(Method) %>%
  summarise(
    Mean = mean(xi, na.rm = TRUE),
    Median = median(xi, na.rm = TRUE),
    Q25 = quantile(xi, 0.25, na.rm = TRUE),
    Q75 = quantile(xi, 0.75, na.rm = TRUE),
    IQR = Q75 - Q25,
    .groups = "drop"
  ) %>%
  mutate(Label = sprintf("Mean = %.3f", Mean))

p2_boxplot <- ggplot(xi_data, aes(x = Method, y = xi, fill = Method)) +
  # Reference line for true value
  geom_hline(yintercept = true_xi, 
             color = "black", size = 1.2, linetype = "dashed") +
  # Boxplot
  geom_boxplot(alpha = 0.7, outlier.shape = NA, width = 0.6, 
               lwd = 0.8, fatten = 1.2) +
  # Jittered points (with lower alpha for clarity)
  geom_jitter(width = 0.12, alpha = 0.25, size = 1.2) +
  # Mean points
  geom_point(data = xi_summary, 
             aes(x = Method, y = Mean),
             color = "black", size = 4, shape = 23, fill = "gold") +
  # Add mean labels
  geom_text(data = xi_summary,
            aes(x = Method, y = Mean, label = Label),
            vjust = -1.2, size = 3.5, fontface = "bold") +
  scale_fill_manual(values = method_colors) +
  labs(x = "Estimation Method",
       y = expression(hat(xi)),
       title = expression("Distribution of" ~ hat(xi) ~ "Estimates (n = 50)"),
       subtitle = sprintf("True ξ = %.2f  |  Gold diamond = Mean estimate", true_xi),
       caption = "Dashed line: True parameter value | Points: Individual estimates") +
  theme_bw(base_size = 13) +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
        plot.subtitle = element_text(hjust = 0.5, size = 12, color = "gray40"),
        plot.caption = element_text(hjust = 0, size = 10, color = "gray40"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text.x = element_text(angle = 35, hjust = 1, size = 11),
        axis.text.y = element_text(size = 11),
        legend.position = "none",
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(color = "gray90", size = 0.5))

print(p2_boxplot)

# --- Plot 3: Convergence of ξ Estimates ---------------------------------------
# Shows mean estimate as sample size increases (without SE if not available)

# Check if SE_Est exists in estimates_table
has_se <- "SE_Est" %in% colnames(estimates_table)

conv_xi <- estimates_table %>%
  filter(Parameter == "xi") %>%
  mutate(True_Value = true_xi)

p3_convergence <- ggplot(conv_xi, aes(x = n, y = Mean_Est, color = Method)) +
  # True value reference line
  geom_hline(yintercept = true_xi,
             color = "black", size = 1.2, linetype = "dashed") +
  # Main line
  geom_line(size = 1.5) +
  # Points
  geom_point(size = 3.5, shape = 21, fill = "white", stroke = 1.2) +
  scale_x_log10(breaks = sample_sizes,
                labels = sample_sizes) +
  scale_y_continuous(breaks = pretty_breaks()) +
  scale_color_manual(values = method_colors) +
  labs(x = expression("Sample Size" ~ italic(n)),
       y = expression("Mean" ~ hat(xi)),
       title = expression("Convergence of" ~ hat(xi) ~ "Estimates"),
       subtitle = sprintf("Estimates should converge to ξ = %.2f (dashed line)", true_xi),
       color = "Method") +
  theme_bw(base_size = 13) +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
        plot.subtitle = element_text(hjust = 0.5, size = 12, color = "gray40"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text = element_text(size = 11),
        legend.position = "bottom",
        legend.title = element_text(face = "bold"),
        legend.text = element_text(size = 10),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(color = "gray90", size = 0.5)) +
  guides(color = guide_legend(nrow = 2, byrow = TRUE))

# Add confidence bands if SE_Est exists
if (has_se) {
  p3_convergence <- p3_convergence +
    geom_ribbon(aes(ymin = Mean_Est - SE_Est, 
                    ymax = Mean_Est + SE_Est,
                    fill = Method),
                alpha = 0.2, color = NA) +
    scale_fill_manual(values = method_colors)
}

print(p3_convergence)

# --- Plot 4: Performance Heatmap for ξ ---------------------------------------
# Shows RMSE values for all methods × sample sizes

# Prepare heatmap matrix
heatmat <- rmse_table %>%
  select(Method, n, RMSE_xi) %>%
  reshape2::dcast(Method ~ n, value.var = "RMSE_xi")

# Convert to matrix for heatmap
heatmat_matrix <- as.matrix(heatmat[, -1])
rownames(heatmat_matrix) <- heatmat$Method

# Scale rows for better comparison (z-score)
heatmat_scaled <- t(scale(t(heatmat_matrix)))

# Melt for ggplot
heat_long <- reshape2::melt(heatmat_scaled, 
                            varnames = c("Method", "n"),
                            value.name = "Scaled_RMSE")
heat_long$n <- as.numeric(as.character(heat_long$n))

# Prepare RMSE values for text labels
rmse_values <- reshape2::melt(heatmat_matrix, 
                              varnames = c("Method", "n"),
                              value.name = "RMSE")
rmse_values$n <- as.numeric(as.character(rmse_values$n))

p4_heatmap <- ggplot(heat_long, aes(x = factor(n), y = Method, fill = Scaled_RMSE)) +
  geom_tile(color = "white", size = 1.2) +
  # Add actual RMSE values as text
  geom_text(data = rmse_values,
            aes(x = factor(n), y = Method, label = sprintf("%.3f", RMSE)),
            color = "black", size = 3.5, fontface = "bold") +
  scale_fill_gradient2(low = "#2b8cbe",      # Blue = good (low RMSE)
                       mid = "#f7f7f7",      # White = average
                       high = "#ca0020",     # Red = bad (high RMSE)
                       midpoint = 0,
                       name = "Scaled RMSE\n(z-score)") +
  labs(x = "Sample Size (n)",
       y = "Method",
       title = expression("Performance Pattern for" ~ hat(xi) ~ "Estimation"),
       subtitle = "Blue = Better performance | Red = Worse performance | Values = RMSE") +
  theme_minimal(base_size = 13) +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
        plot.subtitle = element_text(hjust = 0.5, size = 12, color = "gray40"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text.x = element_text(face = "bold", size = 11),
        axis.text.y = element_text(face = "bold", size = 11),
        legend.title = element_text(face = "bold", size = 11),
        legend.text = element_text(size = 10),
        panel.grid = element_blank())

print(p4_heatmap)

# --- Plot 5: Bias-Variance Tradeoff for ξ at n=50 ---------------------------
# 2D scatter plot showing bias vs variance

# Calculate bias and variance at n=50
bias_var_data <- data.frame()
for (m in methods) {
  estimates <- results[[m]][["50"]]$xi
  estimates <- estimates[!is.na(estimates) & is.finite(estimates)]
  
  if (length(estimates) > 1) {
    bias_var_data <- rbind(bias_var_data,
                           data.frame(
                             Method = m,
                             Bias = mean(estimates, na.rm = TRUE) - true_xi,
                             Variance = var(estimates, na.rm = TRUE),
                             RMSE = sqrt(mean((estimates - true_xi)^2, na.rm = TRUE))
                           ))
  }
}

# Add labels for quadrant interpretation
bias_var_data$Label <- sprintf("%.3f", bias_var_data$RMSE)

# Calculate limits for annotations
xlim_max <- max(abs(bias_var_data$Bias)) * 1.2
ylim_max <- max(sqrt(bias_var_data$Variance)) * 1.2

p5_bias_var <- ggplot(bias_var_data, aes(x = Bias, y = sqrt(Variance))) +
  # Quadrant lines
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray50", size = 0.8) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "gray50", size = 0.8) +
  # Points with size representing RMSE
  geom_point(aes(size = RMSE, color = Method), alpha = 0.9) +
  # Labels for RMSE
  geom_text(aes(label = Label), 
            vjust = -1.2, size = 3.5, fontface = "bold") +
  # Size scale
  scale_size_continuous(name = "RMSE",
                        range = c(5, 12)) +
  scale_color_manual(values = method_colors) +
  coord_cartesian(xlim = c(-xlim_max, xlim_max),
                  ylim = c(0, ylim_max)) +
  # Add interpretation annotations
  annotate("text", x = -xlim_max * 0.6, 
           y = ylim_max * 0.85,
           label = "← Low Bias\nLow Variance\n(IDEAL)", 
           hjust = 0, color = "darkgreen", size = 4, fontface = "bold") +
  annotate("text", x = xlim_max * 0.6, 
           y = ylim_max * 0.85,
           label = "High Bias →\nLow Variance", 
           hjust = 1, color = "orange", size = 4, fontface = "bold") +
  annotate("text", x = -xlim_max * 0.6, 
           y = ylim_max * 0.15,
           label = "Low Bias\nHigh Variance ←", 
           hjust = 0, color = "orange", size = 4, fontface = "bold") +
  annotate("text", x = xlim_max * 0.6, 
           y = ylim_max * 0.15,
           label = "High Bias\nHigh Variance\n(WORST)", 
           hjust = 1, color = "red", size = 4, fontface = "bold") +
  labs(x = expression("Bias = E[" ~ hat(xi) ~ "] - ξ"),
       y = expression("Standard Deviation (" ~ sqrt(Var(hat(xi))) ~ ")"),
       title = expression("Bias-Variance Tradeoff for" ~ hat(xi) ~ "at n = 50"),
       subtitle = "Ideal estimator: close to origin (low bias, low variance)",
       caption = "Point size = RMSE | Label shows RMSE value",
       color = "Method") +
  theme_bw(base_size = 13) +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
        plot.subtitle = element_text(hjust = 0.5, size = 12, color = "gray40"),
        plot.caption = element_text(hjust = 0, size = 10, color = "gray40"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text = element_text(size = 11),
        legend.position = "right",
        legend.title = element_text(face = "bold"),
        legend.text = element_text(size = 10),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(color = "gray90", size = 0.5))

print(p5_bias_var)

# --- Plot 6: Relative Efficiency Comparison for ξ ----------------------------
# Shows efficiency relative to best method at each sample size

rel_eff_xi <- rmse_table %>%
  select(Method, n, RMSE_xi) %>%
  group_by(n) %>%
  mutate(Min_RMSE = min(RMSE_xi, na.rm = TRUE),
         Rel_Efficiency = RMSE_xi / Min_RMSE) %>%
  ungroup()

p6_efficiency <- ggplot(rel_eff_xi, aes(x = n, y = Rel_Efficiency, color = Method)) +
  geom_line(size = 1.5) +
  geom_point(size = 3.5, shape = 21, fill = "white", stroke = 1.2) +
  scale_x_log10(breaks = sample_sizes,
                labels = sample_sizes) +
  scale_y_continuous(breaks = seq(1, max(rel_eff_xi$Rel_Efficiency, na.rm = TRUE), by = 1)) +
  scale_color_manual(values = method_colors) +
  geom_hline(yintercept = 1, color = "red", linetype = "dotted", size = 1) +
  labs(x = expression("Sample Size" ~ italic(n)),
       y = "Relative Efficiency (RMSE / Best RMSE)",
       title = expression("Relative Efficiency for" ~ hat(xi)),
       subtitle = "Values closer to 1.0 indicate better relative performance",
       caption = "Reference line at 1.0 represents the best-performing method",
       color = "Method") +
  theme_bw(base_size = 13) +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
        plot.subtitle = element_text(hjust = 0.5, size = 12, color = "gray40"),
        plot.caption = element_text(hjust = 0, size = 10, color = "gray40"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text = element_text(size = 11),
        legend.position = "bottom",
        legend.title = element_text(face = "bold"),
        legend.text = element_text(size = 10),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(color = "gray90", size = 0.5)) +
  guides(color = guide_legend(nrow = 2, byrow = TRUE))

print(p6_efficiency)

# --- Plot 7: QQ-plot style - Empirical vs Theoretical Distribution -----------
# Compare distribution of estimates to true value

# Prepare data for density plot
density_data <- data.frame()
for (m in methods) {
  estimates <- results[[m]][["50"]]$xi
  estimates <- estimates[!is.na(estimates) & is.finite(estimates)]
  if (length(estimates) > 0) {
    # Trim extreme values for better visualization
    q <- quantile(estimates, c(0.01, 0.99), na.rm = TRUE)
    estimates <- pmax(pmin(estimates, q[2]), q[1])
    density_data <- rbind(density_data,
                          data.frame(Method = m, xi = estimates))
  }
}

p7_density <- ggplot(density_data, aes(x = xi, fill = Method, color = Method)) +
  geom_density(alpha = 0.3, size = 1.2) +
  geom_vline(xintercept = true_xi, 
             color = "black", size = 1.2, linetype = "dashed") +
  scale_fill_manual(values = method_colors) +
  scale_color_manual(values = method_colors) +
  labs(x = expression(hat(xi)),
       y = "Density",
       title = expression("Distribution of" ~ hat(xi) ~ "Estimates (n = 50)"),
       subtitle = sprintf("True ξ = %.2f (vertical dashed line)", true_xi),
       fill = "Method",
       color = "Method") +
  theme_bw(base_size = 13) +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
        plot.subtitle = element_text(hjust = 0.5, size = 12, color = "gray40"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text = element_text(size = 11),
        legend.position = "bottom",
        legend.title = element_text(face = "bold"),
        legend.text = element_text(size = 10),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(color = "gray90", size = 0.5)) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE),
         color = guide_legend(nrow = 2, byrow = TRUE))

print(p7_density)

# --- Create Combined Figure for Publication ----------------------------------

# Combine selected plots
combined_xi <- (p1_rmse + p2_boxplot) /
  (p3_convergence + p5_bias_var) /
  (p4_heatmap + p6_efficiency) +
  plot_annotation(
    title = expression("Comprehensive Evaluation of" ~ hat(xi) ~ "Estimation Methods"),
    subtitle = sprintf("True ξ = %.2f", true_xi),
    tag_levels = 'A',
    theme = theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 18),
                  plot.subtitle = element_text(hjust = 0.5, size = 14, color = "gray40"))
  ) +
  plot_layout(guides = 'collect') &
  theme(legend.position = 'bottom',
        legend.box = 'horizontal')

print(combined_xi)

# --- Save High-Resolution Figures for Publication ----------------------------

# Create directory for figures if it doesn't exist
if (!dir.exists("figures")) dir.create("figures")

# Individual plots
ggsave("figures/Figure1_RMSE_xi.pdf", p1_rmse, width = 10, height = 6, dpi = 300)
ggsave("figures/Figure2_Boxplot_xi.pdf", p2_boxplot, width = 9, height = 7, dpi = 300)
ggsave("figures/Figure3_Convergence_xi.pdf", p3_convergence, width = 10, height = 6, dpi = 300)
ggsave("figures/Figure4_Heatmap_xi.pdf", p4_heatmap, width = 9, height = 6, dpi = 300)
ggsave("figures/Figure5_BiasVariance_xi.pdf", p5_bias_var, width = 10, height = 7, dpi = 300)
ggsave("figures/Figure6_Efficiency_xi.pdf", p6_efficiency, width = 10, height = 6, dpi = 300)
ggsave("figures/Figure7_Density_xi.pdf", p7_density, width = 10, height = 6, dpi = 300)

# Combined figure
ggsave("figures/Combined_Figure_xi.pdf", combined_xi, 
       width = 14, height = 18, dpi = 300)

# High-resolution PNG versions
ggsave("figures/Figure1_RMSE_xi.png", p1_rmse, width = 10, height = 6, dpi = 300)
ggsave("figures/Figure2_Boxplot_xi.png", p2_boxplot, width = 9, height = 7, dpi = 300)
ggsave("figures/Combined_Figure_xi.png", combined_xi, 
       width = 14, height = 18, dpi = 300)

cat("\n✅ All figures saved to 'figures/' directory\n\n")

# --- Print Summary Statistics for Report ------------------------------------

cat("\n========== SUMMARY STATISTICS FOR ξ ESTIMATION ==========\n\n")

for (m in methods) {
  cat(sprintf("\n%s:\n", m))
  cat("--------------------------------------------------\n")
  
  # At n=50
  est_50 <- results[[m]][["50"]]$xi
  est_50 <- est_50[!is.na(est_50) & is.finite(est_50)]
  
  if (length(est_50) > 0) {
    cat("  n = 50:\n")
    cat(sprintf("    Mean:     %.4f\n", mean(est_50, na.rm = TRUE)))
    cat(sprintf("    Bias:     %.4f\n", mean(est_50, na.rm = TRUE) - true_xi))
    cat(sprintf("    Variance: %.4f\n", var(est_50, na.rm = TRUE)))
    cat(sprintf("    RMSE:     %.4f\n", sqrt(mean((est_50 - true_xi)^2, na.rm = TRUE))))
  }
  
  # At largest sample size
  n_max <- max(sample_sizes)
  est_max <- results[[m]][[as.character(n_max)]]$xi
  est_max <- est_max[!is.na(est_max) & is.finite(est_max)]
  
  if (length(est_max) > 0) {
    cat(sprintf("\n  n = %d:\n", n_max))
    cat(sprintf("    Mean:     %.4f\n", mean(est_max, na.rm = TRUE)))
    cat(sprintf("    Bias:     %.4f\n", mean(est_max, na.rm = TRUE) - true_xi))
    cat(sprintf("    Variance: %.4f\n", var(est_max, na.rm = TRUE)))
    cat(sprintf("    RMSE:     %.4f\n", sqrt(mean((est_max - true_xi)^2, na.rm = TRUE))))
  }
  cat("\n")
}

# --- Additional: Ranking of Methods by Performance --------------------------

cat("\n========== METHOD RANKING BY PERFORMANCE ==========\n\n")

# Rank by RMSE at largest sample size
ranking <- rmse_table %>%
  filter(n == max(sample_sizes)) %>%
  arrange(RMSE_xi) %>%
  select(Method, RMSE_xi)

cat("Ranking by RMSE (lowest is best) at n =", max(sample_sizes), "\n")
print(ranking)

# Rank by bias at n=50
bias_ranking <- bias_var_data %>%
  arrange(abs(Bias)) %>%
  select(Method, Bias, Variance, RMSE)

cat("\nRanking by |Bias| at n = 50\n")
print(bias_ranking)

cat("\n========== SUMMARY STATISTICS FOR ξ ESTIMATION ==========\n\n")

for (m in methods) {
  cat(sprintf("\n%s:\n", m))
  cat("--------------------------------------------------\n")
  
  # At n=50
  est_50 <- results[[m]][["50"]]$xi
  est_50 <- est_50[!is.na(est_50) & is.finite(est_50)]
  
  cat("  n = 50:\n")
  cat(sprintf("    Mean:     %.4f\n", mean(est_50)))
  cat(sprintf("    Bias:     %.4f\n", mean(est_50) - true_xi))
  cat(sprintf("    Variance: %.4f\n", var(est_50)))
  cat(sprintf("    RMSE:     %.4f\n", sqrt(mean((est_50 - true_xi)^2))))
  
  # At largest sample size
  n_max <- max(sample_sizes)
  est_max <- results[[m]][[as.character(n_max)]]$xi
  est_max <- est_max[!is.na(est_max) & is.finite(est_max)]
  
  cat(sprintf("\n  n = %d:\n", n_max))
  cat(sprintf("    Mean:     %.4f\n", mean(est_max)))
  cat(sprintf("    Bias:     %.4f\n", mean(est_max) - true_xi))
  cat(sprintf("    Variance: %.4f\n", var(est_max)))
  cat(sprintf("    RMSE:     %.4f\n", sqrt(mean((est_max - true_xi)^2))))
  cat("\n")
}