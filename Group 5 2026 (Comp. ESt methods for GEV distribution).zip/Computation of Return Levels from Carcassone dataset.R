# =============================================================================
# GEV BLOCK MAXIMA ANALYSIS — CarcasonneHeat
# Consolidated script: load -> clean -> describe -> block -> fit GEV -> return levels
# =============================================================================

# ================================
# 0. LIBRARIES
# ================================
library(evd)
library(extRemes)
library(tidyverse)
library(moments)

# ================================
# 1. LOAD RAW DATA
# ================================
data("CarcasonneHeat")

# CarcasonneHeat is a 4-row matrix:
#   Row 1: station ID (constant)
#   Row 2: date as YYYYMMDD integer
#   Row 3: temperature in tenths of °C
#   Row 4: quality flag (0 = valid, anything else = suspect/missing)

cat("=== ROW PROFILES (raw matrix) ===\n")
for (i in 1:4) {
  cat("Row", i,
      "| min:", min(CarcasonneHeat[i, ]),
      "| max:", max(CarcasonneHeat[i, ]),
      "| unique values:", length(unique(CarcasonneHeat[i, ])),
      "| first 5 values:", CarcasonneHeat[i, 1:5], "\n")
}

station_id   <- CarcasonneHeat[1, ]
dates_raw    <- CarcasonneHeat[2, ]
temperature  <- CarcasonneHeat[3, ]     # tenths of °C
quality_flag <- CarcasonneHeat[4, ]

# ================================
# 2. PARSE DATES + CONVERT UNITS
# ================================
dates_parsed <- as.Date(as.character(dates_raw), format = "%Y%m%d")
temp_celsius <- temperature / 10

cat("\nDate range      :", as.character(min(dates_parsed)), "to",
    as.character(max(dates_parsed)), "\n")
cat("Total raw rows  :", length(dates_parsed), "\n")
cat("Quality issues  :", sum(quality_flag != 0), "\n")
cat("Sentinel missing:", sum(temp_celsius <= -999), "\n")

# ================================
# 3. CLEAN DATA
# ================================
# Keep only: valid quality flag, not a missing sentinel (-9999 tenths),
# and physically plausible for Carcassonne (-30°C to 55°C)
keep <- quality_flag == 0 &
  temp_celsius > -999 &
  temp_celsius >= -30 &
  temp_celsius <= 55

n_removed <- sum(!keep)

df <- data.frame(
  date   = dates_parsed[keep],
  year   = as.integer(format(dates_parsed[keep], "%Y")),
  month  = as.integer(format(dates_parsed[keep], "%m")),
  day    = as.integer(format(dates_parsed[keep], "%d")),
  temp_C = temp_celsius[keep]
)

cat("\nRows before cleaning:", length(temp_celsius), "\n")
cat("Rows removed        :", n_removed, "\n")
cat("Rows after cleaning :", nrow(df), "\n")
str(df)

# ================================
# 4. DESCRIPTIVE STATISTICS (on cleaned data)
# ================================
x <- df$temp_C

q1  <- quantile(x, 0.25)
q2  <- quantile(x, 0.50)
q3  <- quantile(x, 0.75)
iqr_x <- IQR(x)
lower_bound <- q1 - 1.5 * iqr_x
upper_bound <- q3 + 1.5 * iqr_x
outliers    <- x[x < lower_bound | x > upper_bound]

cat("\n")
cat("========== DESCRIPTIVE STATISTICS — CarcasonneHeat (°C) ==========\n")
cat("N observations   :", length(x), "\n")
cat("Missing removed  :", n_removed, "\n")
cat("Mean             :", round(mean(x), 4), "\n")
cat("Median           :", round(median(x), 4), "\n")
cat("Min / Max        :", round(min(x), 4), "/", round(max(x), 4), "\n")
cat("Range            :", round(diff(range(x)), 4), "\n")
cat("Variance / SD    :", round(var(x), 4), "/", round(sd(x), 4), "\n")
cat("CV (%)           :", round((sd(x) / mean(x)) * 100, 3), "\n")
cat("Q1 / Q2 / Q3     :", round(q1, 4), "/", round(q2, 4), "/", round(q3, 4), "\n")
cat("IQR              :", round(iqr_x, 4), "\n")
cat("Skewness         :", round(skewness(x), 4), "\n")
cat("Excess Kurtosis  :", round(kurtosis(x) - 3, 4), "\n")
cat("95th percentile  :", round(quantile(x, 0.95), 4), "\n")
cat("99th percentile  :", round(quantile(x, 0.99), 4), "\n")
cat("99.9th percentile:", round(quantile(x, 0.999), 4), "\n")
cat("MAD              :", round(mad(x), 4), "\n")
cat("Outliers (IQR rule):", length(outliers), "\n")

# ================================
# 5. VISUALISATION
# ================================
p1 <- ggplot(df, aes(x = temp_C)) +
  geom_histogram(aes(y = after_stat(density)), bins = 60,
                 fill = "#2166ac", colour = "white", alpha = 0.8) +
  geom_density(colour = "#d73027", linewidth = 1.1) +
  labs(title    = "Distribution of Daily Temperatures — Carcassonne",
       subtitle = sprintf("n = %d  |  Mean = %.2f°C  |  SD = %.2f°C",
                          length(x), mean(x), sd(x)),
       x = "Temperature (°C)", y = "Density") +
  theme_bw(base_size = 13)

p2 <- ggplot(df, aes(x = factor(month), y = temp_C, fill = factor(month))) +
  geom_boxplot(outlier.colour = "red", outlier.size = 0.8, show.legend = FALSE) +
  scale_x_discrete(labels = month.abb) +
  scale_fill_brewer(palette = "RdYlBu", direction = -1) +
  labs(title = "Monthly Temperature Distribution — Carcassonne",
       x = "Month", y = "Temperature (°C)") +
  theme_bw(base_size = 13)

p3 <- ggplot(df, aes(x = date, y = temp_C)) +
  geom_line(colour = "#636363", linewidth = 0.3, alpha = 0.6) +
  geom_smooth(method = "loess", span = 0.05, colour = "#d73027", se = FALSE, linewidth = 1) +
  labs(title = "Daily Temperature Time Series — Carcassonne",
       x = "Date", y = "Temperature (°C)") +
  theme_bw(base_size = 13)

print(p1)
print(p2)
print(p3)

# ================================
# 6. BLOCK MAXIMA (annual blocks, for GEV)
# ================================
# One block = one calendar year. We keep the single highest daily
# temperature observed within each year and discard the rest.
annual_max <- df |>
  group_by(year) |>
  summarise(max_temp = max(temp_C), n_days = n(), .groups = "drop")

n_blocks <- nrow(annual_max)

cat("\n=== BLOCK MAXIMA (annual) ===\n")
print(annual_max)
cat("Number of blocks (years)   :", n_blocks, "\n")
cat("Avg observations per block :", round(nrow(df) / n_blocks, 1), "\n")
cat("Mean of block maxima       :", round(mean(annual_max$max_temp), 3), "°C\n")
cat("SD of block maxima         :", round(sd(annual_max$max_temp), 3), "°C\n")

# ================================
# 7. FIT GEV TO BLOCK MAXIMA
# ================================
fit_gev <- fgev(annual_max$max_temp)
print(fit_gev)

# Also fit with extRemes for cross-checking / diagnostic plots
fit_extremes <- fevd(annual_max$max_temp, type = "GEV")
summary(fit_extremes)
plot(fit_extremes)

# ================================
# 8. RETURN LEVELS (delta method for CIs)
# ================================
params   <- fit_gev$estimate
se_params <- fit_gev$std.err

mu    <- params["loc"]
sigma <- params["scale"]
xi    <- params["shape"]

se_mu    <- se_params["loc"]
se_sigma <- se_params["scale"]
se_xi    <- se_params["shape"]

return_level <- function(T, mu, sigma, xi) {
  p <- 1 - 1 / T
  y <- -log(p)
  if (abs(xi) < 1e-8) {
    mu - sigma * log(y)                       # Gumbel case
  } else {
    mu + (sigma / xi) * (y^(-xi) - 1)         # Frechet / Weibull case
  }
}

se_return_level <- function(T, mu, sigma, xi, se_mu, se_sigma, se_xi,
                            cov_mu_sigma = 0, cov_mu_xi = 0, cov_sigma_xi = 0) {
  p <- 1 - 1 / T
  y <- -log(p)
  
  if (abs(xi) < 1e-8) {
    dz_dmu    <- 1
    dz_dsigma <- -log(y)
    dz_dxi    <- 0
  } else {
    dz_dmu    <- 1
    dz_dsigma <- (y^(-xi) - 1) / xi
    dz_dxi    <- -(sigma / xi^2) * (y^(-xi) - 1) + (sigma / xi) * (-log(y)) * y^(-xi)
  }
  
  var_z <- dz_dmu^2 * se_mu^2 +
    dz_dsigma^2 * se_sigma^2 +
    dz_dxi^2 * se_xi^2 +
    2 * dz_dmu * dz_dsigma * cov_mu_sigma +
    2 * dz_dmu * dz_dxi * cov_mu_xi +
    2 * dz_dsigma * dz_dxi * cov_sigma_xi
  
  sqrt(var_z)
}

# Use the actual variance-covariance matrix from the fit instead of zeros,
# since loc/scale/shape estimates are correlated.
# NOTE: fgev() does not reliably attach dimnames to var.cov the way it does
# to estimate/std.err, so we re-apply the parameter names ourselves before
# indexing by name (the row/column order of var.cov always matches estimate).
vc <- fit_gev$var.cov
param_names <- names(fit_gev$estimate)
dimnames(vc) <- list(param_names, param_names)

cov_mu_sigma <- vc["loc", "scale"]
cov_mu_xi    <- vc["loc", "shape"]
cov_sigma_xi <- vc["scale", "shape"]

T_vec <- c(2, 5, 10, 20, 25, 50, 100, 200, 500, 1000)

rl_table <- data.frame(T = T_vec, Prob = 1 - 1 / T_vec,
                       Return_Level = NA, SE = NA, CI_Lower = NA, CI_Upper = NA)

for (i in seq_along(T_vec)) {
  T  <- T_vec[i]
  zT <- return_level(T, mu, sigma, xi)
  se <- se_return_level(T, mu, sigma, xi, se_mu, se_sigma, se_xi,
                        cov_mu_sigma, cov_mu_xi, cov_sigma_xi)
  
  rl_table$Return_Level[i] <- round(zT, 4)
  rl_table$SE[i]           <- round(se, 4)
  rl_table$CI_Lower[i]     <- round(zT - 1.96 * se, 4)
  rl_table$CI_Upper[i]     <- round(zT + 1.96 * se, 4)
}

cat("\n=== GEV RETURN LEVELS (annual block maxima) ===\n")
cat("Parameters: mu =", round(mu, 4), " sigma =", round(sigma, 4),
    " xi =", round(xi, 4), "\n")
cat(if (xi > 0) "Shape xi > 0 -> Frechet (heavy tail)\n"
    else if (xi < 0) "Shape xi < 0 -> Weibull (bounded upper tail)\n"
    else "Shape xi = 0 -> Gumbel\n")
print(rl_table)

 